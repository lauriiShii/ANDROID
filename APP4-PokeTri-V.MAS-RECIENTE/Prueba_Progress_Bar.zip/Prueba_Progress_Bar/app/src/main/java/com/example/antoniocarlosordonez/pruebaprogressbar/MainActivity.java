package com.example.antoniocarlosordonez.pruebaprogressbar;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.lytHueco)
    FrameLayout lytHueco;

    static public android.support.v4.app.FragmentManager gestorFragmentos;
    pbFragment fragmento = new pbFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        cargarFragmento();
    }

    private void cargarFragmento() {
        // Obtiene el gestor de fragmentos.
        gestorFragmentos = getSupportFragmentManager();
        // Inicia la transacción de fragmentos.
        FragmentTransaction transaccion = gestorFragmentos.beginTransaction();
        // Reemplaza el fragmento existente en el contenedor lytHueco por el nuevo fragmento.
        transaccion.replace(R.id.lytHueco, fragmento);
        // Se aplican los cambios.
        transaccion.commit();
    }
}

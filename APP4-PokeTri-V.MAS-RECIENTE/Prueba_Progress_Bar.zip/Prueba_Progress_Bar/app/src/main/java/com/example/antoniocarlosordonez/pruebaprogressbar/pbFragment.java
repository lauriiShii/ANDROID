package com.example.antoniocarlosordonez.pruebaprogressbar;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class pbFragment extends Fragment {

    @BindView(R.id.progressBar)
    TextProgressBar progressBar;
    @BindView(R.id.btnNext)
    Button btnNext;
    @BindView(R.id.btnParar)
    Button btnParar;

    Unbinder unbinder;

    boolean parar = false;


    public pbFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    // Retorna la vista que mostrará el fragmento.
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Infla el layout del fragmento.
        View view = inflater.inflate(R.layout.fragment_pb, container, false);
        unbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @OnClick({R.id.btnNext, R.id.btnParar})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btnNext:
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(0);
                parar = false;
                btnNext.setEnabled(false);
                cuentaAtras();
                break;
            case R.id.btnParar:
                progressBar.setVisibility(View.GONE);
                btnNext.setEnabled(true);
                parar = true;
                break;
        }
    }

    private void cuentaAtras() {
        for (int i = 0; i <= progressBar.getMax() && !parar; i++) {
            new TareaSecundaria().execute();
        }
        actualizarEstado();
    }

    private void actualizarEstado() {
        if (progressBar.getProgress() < progressBar.getMax()) {
            progressBar.setText(String.format("%d/%d", progressBar.getProgress(), progressBar.getMax()));
        } else {
            progressBar.setText("GAME OVER");

        }
    }

    // Clase interna para la Tarea Secundaria. Tipos recibidos:
    // - Entrada: El tipo del valor recibido por doInBackground y que se pasa en
    // el método execute().
    // - Progreso: El tipo del valor recibido por onProgressUpdate y que se pasa
    // al hacer publishProgress().
    // - Salida: El tipo del valor recibido por onPostExecute y que corresponde
    // al valor de retorno del doInBackground.
    public class TareaSecundaria extends AsyncTask<Integer, Integer, Integer> {
        // Llamado al lanzar el hilo secundario y corresponde al código que éste
        // ejecuta. Recibe lo que se le pase al método execute() cuando se
        // ejecute la tarea asíncrona. Se puede informar del progreso mediante
        // el método publishProgress().
        @Override
        protected Integer doInBackground(Integer... params) {
            // Se realizan los pasos.
            if (!isCancelled() && !parar) {
                // Se pone a trabajar.
                trabajar();
                progressBar.setProgress(progressBar.getProgress() + 1, true);

                // Informa del progreso.
                publishProgress(progressBar.getProgress() + 1);
            }
            // Se retorna el número de trabajos realizados.
            return 1;
        }

        // Simula un trabajo de 1 segundo.
        private void trabajar() {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
